﻿# Script de Instalacion
param(
    [string]$InstallPath = "C:\inetpub\wwwroot\web-scraping",
    [string]$SiteName = "WebScrapingService",
    [int]$Port = 8080
)

Write-Host "Instalando Web Scraping Service..." -ForegroundColor Green

# Verificar Node.js
if (!(Get-Command "node" -ErrorAction SilentlyContinue)) {
    Write-Host "Error: Node.js no esta instalado" -ForegroundColor Red
    exit 1
}

# Crear directorio
if (!(Test-Path $InstallPath)) {
    New-Item -ItemType Directory -Path $InstallPath -Force
}

# Copiar archivos
Copy-Item -Path ".\web-scraping-service\*" -Destination $InstallPath -Recurse -Force

# Instalar dependencias
Set-Location $InstallPath
npm install --production

Write-Host "Instalacion completada!" -ForegroundColor Green
Write-Host "Para completar el setup, ejecuta el script de deploy desde la carpeta scripts/" -ForegroundColor Yellow
