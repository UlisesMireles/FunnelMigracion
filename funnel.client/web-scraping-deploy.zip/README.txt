﻿# Web Scraping Service - Paquete de Deployment v1.0.0

## Instalacion Rapida
1. Extraer este ZIP en el servidor
2. Abrir PowerShell como Administrador
3. Ejecutar: .\INSTALAR.ps1

## Prerrequisitos
- Windows Server con IIS
- Node.js v18+
- PowerShell como Administrador

Fecha: 2025-08-18 11:58:32
